/* 
 * File:   createDOMDocument.cpp
 * Author: The Apache Software Foundation, http://xerces.apache.org/xerces-c/
 * Editor: Chris Burbine, christopher_burbine@student.uml.edu
 *
 * Created locally on November 6, 2012, 4:45 PM
 * Updated on November 9, 2012, 3:45 PM
 * Updated on November 9, 2012, 7:36 PM
 */

/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * $Id: CreateDOMDocument.cpp 676796 2008-07-15 05:04:13Z dbertoni $
 */

/*
 * This sample illustrates how you can create a DOM tree in memory.
 * It then prints the count of elements in the tree.
 */


// ---------------------------------------------------------------------------
//  Includes
// ---------------------------------------------------------------------------
#include <xercesc/util/PlatformUtils.hpp>
#include <xercesc/util/XMLString.hpp>
#include <xercesc/dom/DOM.hpp>
#include <xercesc/util/OutOfMemoryException.hpp>

#include <xercesc/framework/StdOutFormatTarget.hpp>
#include <xercesc/framework/LocalFileFormatTarget.hpp>
#include <xercesc/parsers/XercesDOMParser.hpp>
#include <xercesc/util/XMLUni.hpp>

#include "DOMTreeErrorReporter.hpp"
#include "DOMPrintFilter.hpp"
#include "DOMPrintErrorHandler.hpp"

#include <string.h>
#include <stdlib.h>


#if defined(XERCES_NEW_IOSTREAMS)
#include <iostream>
#else
#include <iostream.h>
#endif

XERCES_CPP_NAMESPACE_USE


// ---------------------------------------------------------------------------
//  This is a simple class that lets us do easy (though not terribly efficient)
//  trancoding of char* data to XMLCh data.
// ---------------------------------------------------------------------------
class XStr {
public:
    // -----------------------------------------------------------------------
    //  Constructors and Destructor
    // -----------------------------------------------------------------------

    XStr(const char* const toTranscode) {
        // Call the private transcoding method
        fUnicodeForm = XMLString::transcode(toTranscode);
    }

    ~XStr() {
        XMLString::release(&fUnicodeForm);
    }


    // -----------------------------------------------------------------------
    //  Getter methods
    // -----------------------------------------------------------------------

    const XMLCh* unicodeForm() const {
        return fUnicodeForm;
    }

private:
    // -----------------------------------------------------------------------
    //  Private data members
    //
    //  fUnicodeForm
    //      This is the Unicode XMLCh format of the string.
    // -----------------------------------------------------------------------
    XMLCh* fUnicodeForm;
};

#define X(str) XStr(str).unicodeForm()

static char* goutputfile = 0;
static char* gXPathExpression = 0;

// options for DOMLSSerializer's features
static XMLCh* gOutputEncoding = 0;

static bool gSplitCdataSections = true;
static bool gDiscardDefaultContent = true;
static bool gUseFilter = false;
static bool gFormatPrettyPrint = true;
static bool gWriteBOM = false;

/**
 * Prints a parsed xml file in pretty-print format
 * @param doc document to be printed
 * @return return value dependent on the result of the print
 */
int DOMPrint(DOMDocument* doc) {
    int retval = 0;
    
    try{ //attempts to initialize a platform
        XMLPlatformUtils::Initialize();
    }
    
    catch( const XMLException &toCatch){ //catch error os there is an issue
        XERCES_STD_QUALIFIER cerr << "Error during Xerces-c Initialization.\n"
                << "  Exception message:"
                << StrX(toCatch.getMessage()) << XERCES_STD_QUALIFIER endl;
        return 1;
    }
    
    /** possible future error checking value; at the moment does nothing*/
    bool errorsOccured = false;
    
    if (!errorsOccured ) {
        DOMPrintFilter *myFilter = 0;

        try {
            // get a serializer, an instance of DOMLSSerializer
            XMLCh tempStr[3] = {chLatin_L, chLatin_S, chNull};
            DOMImplementation *impl = DOMImplementationRegistry::getDOMImplementation(tempStr);
            DOMLSSerializer *theSerializer = ((DOMImplementationLS*) impl)->createLSSerializer();
            DOMLSOutput *theOutputDesc = ((DOMImplementationLS*) impl)->createLSOutput();

            // set user specified output encoding
            theOutputDesc->setEncoding(gOutputEncoding);

            // plug in user's own filter
            if (gUseFilter) {
                // even we say to show attribute, but the DOMLSSerializer
                // will not show attribute nodes to the filter as
                // the specs explicitly says that DOMLSSerializer shall
                // NOT show attributes to DOMLSSerializerFilter.
                //
                // so DOMNodeFilter::SHOW_ATTRIBUTE has no effect.
                // same DOMNodeFilter::SHOW_DOCUMENT_TYPE, no effect.
                //
                myFilter = new DOMPrintFilter(DOMNodeFilter::SHOW_ELEMENT |
                        DOMNodeFilter::SHOW_ATTRIBUTE |
                        DOMNodeFilter::SHOW_DOCUMENT_TYPE);
                theSerializer->setFilter(myFilter);
            }

            // plug in user's own error handler
            DOMErrorHandler *myErrorHandler = new DOMPrintErrorHandler();
            DOMConfiguration* serializerConfig = theSerializer->getDomConfig();
            serializerConfig->setParameter(XMLUni::fgDOMErrorHandler, myErrorHandler);

            // set feature if the serializer supports the feature/mode
            if (serializerConfig->canSetParameter(XMLUni::fgDOMWRTSplitCdataSections, gSplitCdataSections))
                serializerConfig->setParameter(XMLUni::fgDOMWRTSplitCdataSections, gSplitCdataSections);

            if (serializerConfig->canSetParameter(XMLUni::fgDOMWRTDiscardDefaultContent, gDiscardDefaultContent))
                serializerConfig->setParameter(XMLUni::fgDOMWRTDiscardDefaultContent, gDiscardDefaultContent);

            if (serializerConfig->canSetParameter(XMLUni::fgDOMWRTFormatPrettyPrint, gFormatPrettyPrint))
                serializerConfig->setParameter(XMLUni::fgDOMWRTFormatPrettyPrint, gFormatPrettyPrint);

            if (serializerConfig->canSetParameter(XMLUni::fgDOMWRTBOM, gWriteBOM))
                serializerConfig->setParameter(XMLUni::fgDOMWRTBOM, gWriteBOM);

            //
            // Plug in a format target to receive the resultant
            // XML stream from the serializer.
            //
            // StdOutFormatTarget prints the resultant XML stream
            // to stdout once it receives any thing from the serializer.
            //
            XMLFormatTarget *myFormTarget;
            if (goutputfile)
                myFormTarget = new LocalFileFormatTarget(goutputfile);
            else
                myFormTarget = new StdOutFormatTarget();
            theOutputDesc->setByteStream(myFormTarget);


            //
            // do the serialization through DOMLSSerializer::write();
            //
            if (gXPathExpression != NULL) {
                XMLCh* xpathStr = XMLString::transcode(gXPathExpression);
                DOMElement* root = doc->getDocumentElement();
                try {
                    DOMXPathNSResolver* resolver = doc->createNSResolver(root);
                    DOMXPathResult* result = doc->evaluate(
                            xpathStr,
                            root,
                            resolver,
                            DOMXPathResult::ORDERED_NODE_SNAPSHOT_TYPE,
                            NULL);

                    XMLSize_t nLength = result->getSnapshotLength();
                    for (XMLSize_t i = 0; i < nLength; i++) {
                        result->snapshotItem(i);
                        theSerializer->write(result->getNodeValue(), theOutputDesc);
                    }

                    result->release();
                    resolver->release();
                }                catch (const DOMXPathException& e) {
                    XERCES_STD_QUALIFIER cerr << "An error occurred during processing of the XPath expression. Msg is:"
                            << XERCES_STD_QUALIFIER endl
                            << StrX(e.getMessage()) << XERCES_STD_QUALIFIER endl;
                    retval = 4;
                }                catch (const DOMException& e) {
                    XERCES_STD_QUALIFIER cerr << "An error occurred during processing of the XPath expression. Msg is:"
                            << XERCES_STD_QUALIFIER endl
                            << StrX(e.getMessage()) << XERCES_STD_QUALIFIER endl;
                    retval = 4;
                }
                XMLString::release(&xpathStr);
            } else
                theSerializer->write(doc, theOutputDesc);

            theOutputDesc->release();
            theSerializer->release();

            //
            // Filter, formatTarget and error handler
            // are NOT owned by the serializer.
            //
            delete myFormTarget;
            delete myErrorHandler;

            if (gUseFilter)
                delete myFilter;

        }        catch (const OutOfMemoryException&) {
            XERCES_STD_QUALIFIER cerr << "OutOfMemoryException" << XERCES_STD_QUALIFIER endl;
            retval = 5;
        }        catch (XMLException& e) {
            XERCES_STD_QUALIFIER cerr << "An error occurred during creation of output transcoder. Msg is:"
                    << XERCES_STD_QUALIFIER endl
                    << StrX(e.getMessage()) << XERCES_STD_QUALIFIER endl;
            retval = 4;
        }

    } else
        retval = 4;


    XMLString::release(&gOutputEncoding);

    // And call the termination method
    XMLPlatformUtils::Terminate();

    return retval;
    
}

/**
 * Function called to add elements to the tree
 * @param name name of new node
 * @param cont content of new node, maybe empty
 * @param parentNode name of node where the new node will be appended under
 * @param doc document in which all this is occurring 
 * @param rootElem shows the walker where to start
 */
void addELem(std::string name, std::string cont, std::string parentNode, DOMDocument* doc, DOMElement *rootElem ){
    
    //creates a walker to move along the tree
    DOMTreeWalker* walker = doc->createTreeWalker(rootElem, DOMNodeFilter::SHOW_ALL, NULL, true) ;
    //for loop iterates through the tree
    for (DOMNode* current = walker->getCurrentNode(); current != 0; current = walker->nextNode() ) {
      //std::cout << "Entering loop" << std::endl;
      const char* temp = XMLString::transcode(current->getNodeName());
      //attaches new node to tree when the correct parent node is found 
      if( temp == parentNode ){
          //std::cout << "Creating new node" << std::endl;
          DOMElement *newElement = doc->createElement(X(name.c_str()));
          //std::cout << "Attaching new node" << std::endl;
          current->appendChild(newElement);
          
          //attaches content to new node if there is any
          int size = cont.size();
          if( size > 0 ){
             DOMText* newElementCont = doc->createTextNode(X(cont.c_str()));
             newElement->appendChild(newElementCont);
          }
                                        
          //DOMPrint( doc );
      } 
   }
}

/**
 * Function called to add attributes to a tree
 * @param name name of new attribute
 * @param val value of new attribute
 * @param parentNode name of node the attribute will be placed under
 * @param doc document which this is happening in
 * @param rootElem shows walker where to start
 */
void addAttr( std::string name, std::string val, std::string parentNode, DOMDocument* doc, DOMElement* rootElem ){
    //creates a walker to move along the tree
    DOMTreeWalker* walker = doc->createTreeWalker(rootElem, DOMNodeFilter::SHOW_ALL, NULL, true) ;
    //for loop iterates through the tree
    for (DOMNode* current = walker->getCurrentNode(); current != 0; current = walker->nextNode() ) {
        const char* temp = XMLString::transcode(current->getNodeName());
        //attaches new node to tree when the correct parent node is found
        if( temp == parentNode ){
            DOMAttr *newAttr = doc->createAttribute(X(name.c_str()));
            newAttr->setValue(X(val.c_str()));
            
            DOMNamedNodeMap *newMap = current->getAttributes();
            newMap->setNamedItem(newAttr);
            
            //DOMPrint( doc );
        }
    }
}


// ---------------------------------------------------------------------------
//  main
// ---------------------------------------------------------------------------

int main(int argC, char*[]) {
    // Initialize the XML4C2 system.
    try {
        XMLPlatformUtils::Initialize();
    } catch (const XMLException& toCatch) {
        char *pMsg = XMLString::transcode(toCatch.getMessage());
        XERCES_STD_QUALIFIER cerr << "Error during Xerces-c Initialization.\n"
                << "  Exception message:"
                << pMsg;
        XMLString::release(&pMsg);
        return 1;
    }

    // Watch for special case help request
    int errorCode = 0;
    if (argC > 1) {
        XERCES_STD_QUALIFIER cout << "\nUsage:\n"
                "    CreateDOMDocument\n\n"
                "This program creates a new DOM document from scratch in memory.\n"
                "It then prints the count of elements in the tree.\n"
                << XERCES_STD_QUALIFIER endl;
        errorCode = 1;
    }
    if (errorCode) {
        XMLPlatformUtils::Terminate();
        return errorCode;
    }

    {

        DOMImplementation* impl = DOMImplementationRegistry::getDOMImplementation(X("Core"));

        /** code moded here to print course in for including the code name and number, the professor and five students from the roster; 
         data for xml file provided by Prof Heines from http://teaching.cs.uml.edu/~heines/91.204/91.204-2012-13f/204-assn/CreatingADOMDocument-Part1-v01.jsp*/
        if (impl != NULL) {
            try {
                DOMDocument* doc = impl->createDocument(
                        0, // root element namespace URI.
                        X("course"), // root element name
                        0); // document type object (DTD).

                DOMElement* rootElem = doc->getDocumentElement();
                
                DOMComment* topComment = doc->createComment(X("\n"
                        "  File:  /~heines/91.204/91.204-2012-13s/course.xml\n"
                        "  Jesse M. Heines, UMass Lowell Computer Science, heines@cs.uml.edu\n"
                        "  Copyright (c) 2012 by Jesse M. Heines.  All rights reserved.  May be freely\n"
                        "    copied or excerpted for educational purposes with credit to the author.\n"
                        "  updated by JMH on September 21, 2012 at 12:35 PM\n\n"
                        "  N.B. Use &#146; rather than ' in names such as O'Connell to avoid XSL errors.\n"));
                rootElem->appendChild(topComment);
                
                DOMElement* timeStElem = doc->createElement(X("timestamp"));
                rootElem->appendChild(timeStElem);

                DOMText* timeStDataVal = doc->createTextNode(X("updated by JMH on October 27, 2012 at 5:33 PM"));
                timeStElem->appendChild(timeStDataVal);

                DOMElement* titleElem = doc->createElement(X("title"));
                rootElem->appendChild(titleElem);

                DOMText* titleDateVal = doc->createTextNode(X("Computing IV"));
                titleElem->appendChild(titleDateVal);
                
                DOMElement* sectionElem = doc->createElement(X("section"));
                rootElem->appendChild(sectionElem);
                
                DOMText* sectionDataVal = doc->createTextNode(X("201"));
                sectionElem->appendChild(sectionDataVal);
                
                DOMElement* semesterElem = doc->createElement(X("semester"));
                rootElem->appendChild(semesterElem);
                
                DOMText* semesterDataVal = doc->createTextNode(X("2012-13s"));
                semesterElem->appendChild(semesterDataVal);
                
                DOMElement* academic_calendarElem = doc->createElement(X("academic-calendar-link-pdf"));
                rootElem->appendChild(academic_calendarElem);
                
                DOMText* academic_calendarDataVal = doc->createTextNode(X("http://www.uml.edu/docs/Acal_2012F_tcm18-52133.pdf"));
                academic_calendarElem->appendChild(academic_calendarDataVal);
                
                DOMElement* discussion_boardElem = doc->createElement(X("discussion-board"));
                rootElem->appendChild(discussion_boardElem);
                
                DOMText* discussion_boardDataVal = doc->createTextNode(X("http://piazza.com/class#fall2012/91204"));
                discussion_boardElem->appendChild(discussion_boardDataVal);
                
                DOMElement* class_videosElem = doc->createElement(X("class-videos-url"));
                rootElem->appendChild(class_videosElem);
                
                DOMText* class_videosDataVal = doc->createTextNode(X("http://echo360.uml.edu/heines2012/computing4Fall.html"));
                class_videosElem->appendChild(class_videosDataVal);
                
                DOMElement* professorElem = doc->createElement(X("professor"));
                rootElem->appendChild(professorElem);
                
                DOMElement* profNameElem = doc->createElement(X("name"));
                professorElem->appendChild(profNameElem);
                
                DOMText* profNameDataVal = doc->createTextNode(X("Prof. Jesse M. Heines"));
                profNameElem->appendChild(profNameDataVal);
                
                DOMElement* lastnamefirstElem = doc->createElement(X("lastnamefirst"));
                professorElem->appendChild(lastnamefirstElem);
                
                DOMText* lastnamefirstDataVal = doc->createTextNode(X("Heines, Jesse (Computer Science)"));
                lastnamefirstElem->appendChild(lastnamefirstDataVal);
                
                DOMElement* profEmailElem = doc->createElement(X("email"));
                professorElem->appendChild(profEmailElem);
                
                DOMText* profEmailDataVal = doc->createTextNode(X("heines@cs.uml.edu"));
                profEmailElem->appendChild(profEmailDataVal);
                
                DOMElement* rosterElem = doc->createElement(X("roster"));
                rootElem->appendChild(rosterElem);
                
                DOMElement* studentAlvesElem = doc->createElement(X("student"));
                rosterElem->appendChild(studentAlvesElem);
                
                studentAlvesElem->setAttribute(X("name"), X("Alves, Andrew Richard"));
                studentAlvesElem->setAttribute(X("major"), X("Computer Engineering (BSE)"));
                studentAlvesElem->setAttribute(X("wantstobecalled"), X("Andrew"));
                
                DOMElement* studentAlvesEmailElem = doc->createElement(X("email"));
                studentAlvesElem->appendChild(studentAlvesEmailElem);
                
                DOMText* studentAlvesEmailDataVal = doc->createTextNode(X("acdandrew@gmail.com"));
                studentAlvesEmailElem->appendChild(studentAlvesEmailDataVal);
                
                DOMElement* studentColinElem = doc->createElement(X("student"));
                rosterElem->appendChild(studentColinElem);
                
                studentColinElem->setAttribute(X("name"), X("Baillie, Colin Domigan"));
                studentColinElem->setAttribute(X("major"), X("Computer Science (BS)"));
                studentColinElem->setAttribute(X("wantstobecalled"), X("Colin"));
                
                DOMElement* studentColinEmailElem = doc->createElement(X("email"));
                studentColinElem->appendChild(studentColinEmailElem);
                
                DOMText* studentColinEmailDataVal = doc->createTextNode(X("domigan16@gmail.com"));
                studentColinEmailElem->appendChild(studentColinEmailDataVal);
                
                DOMElement* studentDanielElem = doc->createElement(X("student"));
                rosterElem->appendChild(studentDanielElem);
                
                studentDanielElem->setAttribute(X("name"), X("Brook, Daniel M."));
                studentDanielElem->setAttribute(X("major"), X("Computer Science (BS)"));
                studentDanielElem->setAttribute(X("wantstobecalled"), X("Dan"));
                
                DOMElement* studentDanielEmailElem = doc->createElement(X("email"));
                studentDanielElem->appendChild(studentDanielEmailElem);
                
                DOMText* studentDanielEmailDataVal = doc->createTextNode(X("Daniel_Brook@student.uml.edu"));
                studentDanielEmailElem->appendChild(studentDanielEmailDataVal);
                
                DOMElement* studentChrisElem = doc->createElement(X("student"));
                rosterElem->appendChild(studentChrisElem);
                
                studentChrisElem->setAttribute(X("name"), X("Burbine, Christopher"));
                studentChrisElem->setAttribute(X("major"), X("Computer Science (BS)"));
                studentChrisElem->setAttribute(X("wantstobecalled"), X("Chris"));
                
                DOMElement* studentChrisEmailElem = doc->createElement(X("email"));
                studentChrisElem->appendChild(studentChrisEmailElem);
                
                DOMText* studentChrisEmailDataVal = doc->createTextNode(X("Christopher_Burbine@student.uml.edu"));
                studentChrisEmailElem->appendChild(studentChrisEmailDataVal);
                
                DOMElement* studentJoshElem = doc->createElement(X("student"));
                rosterElem->appendChild(studentJoshElem);
                
                studentJoshElem->setAttribute(X("name"), X("Caravetta, Joshua David"));
                studentJoshElem->setAttribute(X("major"), X("Electrical Engineering (BSE)"));
                studentJoshElem->setAttribute(X("wantstobecalled"), X("Josh"));
                
                DOMElement* studentJoshEmailElem = doc->createElement(X("email"));
                studentJoshElem->appendChild(studentJoshEmailElem);
                
                DOMText* studentJoshEmailDataVal = doc->createTextNode(X("Joshua_Caravetta@student.uml.edu"));
                studentJoshEmailElem->appendChild(studentJoshEmailDataVal);
                
                
                //
                // Now count the number of elements in the above DOM tree.
                //

                const XMLSize_t elementCount = doc->getElementsByTagName(X("*"))->getLength();
                XERCES_STD_QUALIFIER cout << "The tree just created contains: " << elementCount
                        << " elements.\n" << XERCES_STD_QUALIFIER endl;
                
                // XML print function call
                //DOMPrint( doc );
                
                std::string answer; //string used to store user answers
                std::string type; //string used to store specified types
                std::string printType; //string used to store print types
                std::string newName; //holds name of new element or attribute
                std::string newContVal; //holds content of new element or value of new attribute
                std::string parentNode; //holds name of parent node
                bool treeModCheck = true; //bool that tells the while loop to keep looping or not
                
                //while loop below asks a series of questions to the user in order to find out they want to do to the tree
                while( treeModCheck == true ){
                    std::cout << "What would you like to do with the tree (Add/Print/Quit)?" <<std::endl;
                    std::cin >> answer;
                    
                    //if statement entered of they wish to add to the tree
                    if( answer == "Add" || answer == "ADD" || answer == "add" || answer == "a" || answer == "A" ){
                        std::cout << "Please enter what type of node you would like to add to the tree (Elem/Attr)." << std::endl;
                        std::cin >> type;
                        //if they wish to add an element
                        if( type == "elem" || type =="Elem" || type == "ELEM" || type == "e" || type == "E"){
                            std::cout << "What would you like to name this element to be?" << std::endl;
                            std::cin >> newName;
                            std::cout << "Would you like to add any content to this node?(Y/N)" << std::endl;
                            std::cin >> answer;
                            if( answer == "Y" || answer == "y" || answer == "Yes"|| answer =="yes" || answer == "YES" ){
                                std::cout << "What would you like to add as content to the new node?" << std::endl;
                                std::cin >> newContVal;
                            }
                            std::cout << "What if the name of the element that you would like to attach this new node to?" << std::endl;
                            std::cin >> parentNode;
                                
                            addELem(newName, newContVal, parentNode, doc, rootElem);
                            
                          //if they wish to add a attribute
                        } else if (type == "attr" || type == "Attr" || type == "ATTR" || type == "a" || type == "A"){
                            std::cout << "What would you like to name this attribute to be?" << std::endl;
                            std::cin >> newName;
                            std::cout << "What would you like to add as value to the new node?" << std::endl;
                            std::cin >> newContVal;
                            std::cout << "What if the name of the element that you would like to attach this new node to?" << std::endl;
                            std::cin >> parentNode;
                            
                            addAttr( newName, newContVal, parentNode, doc, rootElem );
                        }
                      
                        //else if the user wishes to print the current tree
                    } else if( answer == "print" || answer == "p" || answer == "Print" || answer == "PRINT" || answer == "P" ){
                        std::cout << "Print requested, would you like it printed in XML or node by node (XML/Node)?" << std::endl;
                        std::cin >> printType;
                        //prints the tree and a straight xml doc to the command line
                        if( printType == "XML" || printType == "xml" || printType == "Xml" || printType == "x" || printType == "X" ){
                            std::cout << "Printing the raw XML document..." << std::endl;
                            DOMPrint( doc );
                            //prints the tree node by node 
                        } else if ( printType == "node" || printType == "Node" || printType == "n" || printType == "N" || printType == "NODE" ){
                            std::cout << "Printing node by node..." << std::endl;
                            // code below(lines 591-642) taken from: ???
                            //http://teaching.cs.uml.edu/~heines/91.204/91.204-2012-13f/204-lecs/lecture21.jsp
                            // provided by Prof. Heines
            
                            std::cout << "\n------------------------------" << std::endl;
            
                            // JMH: http://www.ibm.com/developerworks/xml/library/x-xercc2/
                            // JMH: but note that a DOMTreeWalker* is returned, not a DOMTreeWalker
                            // JMH: this was learned by using NetBeans autocomplete
 
                            // JMH: Note that SHOW_ATTRIBUTE is meaningful only when creating an DOMNodeIterator or
                            // DOMTreeWalker with an attribute node as its root; in this case, it means that the attribute
                            // node will appear in the first position of the iteration or traversal. Since attributes are
                            // never children of other nodes, they do not appear when traversing over the document tree.
                            //   -- http://xerces.apache.org/xerces-c/apiDocs-3/classDOMNodeFilter.html

                            // JMH: See http://xerces.apache.org/xerces-c/apiDocs-3/classDOMNode.html#6237ede96be83ff729807688e4f638c5
                            // for table of values of nodeName, nodeValue, and attributes for given node types
 
                            // create a walker to visit all text nodes
                            // DOMTreeWalker* walker = doc->createTreeWalker(elemRoot, DOMNodeFilter::SHOW_TEXT, NULL, true) ;
                            DOMTreeWalker* walker = doc->createTreeWalker(rootElem, DOMNodeFilter::SHOW_ALL, NULL, true) ;
                            for (DOMNode* current = walker->getCurrentNode(); current != 0; current = walker->nextNode() ) {
                                // note: this leaks memory!
                                // std::cout << current->getNodeValue() << std::endl ; // .transcode();
                                // JMH: the following was found in DOMPrint.cpp
                                // JMH: see also http://xerces.apache.org/xerces-c/apiDocs-3/classDOMNode.html
                                // std::cout << current->getNodeType() << " | " ;
                                // JMH: see http://xerces.apache.org/xerces-c/apiDocs-3/classXMLString.html for equals()
                                if ( ! XMLString::equals( XMLString::transcode(current->getNodeName()), "#text" ) )  {
                                    std::cout << "\nNode Name: " << XMLString::transcode(current->getNodeName()) << " | " ;
                                }
                                if ( current->getNodeValue() != NULL ) {
                                    std::cout << "Node Value: " << XMLString::transcode(current->getNodeValue()) << " | " ;
                                }
                     
                                // see http://xerces.apache.org/xerces-c/apiDocs-3/classDOMNode.html
                                DOMNamedNodeMap *map = current->getAttributes() ;
                                // see http://xerces.apache.org/xerces-c/apiDocs-3/classDOMNamedNodeMap.html
                                if ( map == NULL || map->getLength() == 0 ) {
                                    // std::cout << "no attributes" ;
                                } else {
                                    // std::cout << map->getLength() << " attribute(s)" ;
                                    for ( unsigned int k = 0 ; k < map->getLength() ; k++ ) {
                                        std::cout << "\n  Attribute " << k+1 << ": " <<
                                        XMLString::transcode( map->item( k )->getNodeName() ) << " = " <<
                                        XMLString::transcode( map->item( k )->getNodeValue() ) << " | " ;
                                    }       
                                }
                            }
                                std::cout << std::endl;
                        }
                        //else if the user wishes to quit the tree modding 
                    } else if( answer == "quit" || answer == "q" || answer == "Quit" || answer == "QUIT" || answer == "Q" ){
                        std::cout << "Quitting..." << std::endl;
                        treeModCheck = false;
                    }
                    
            }
                 
            doc->release();
            } catch (const OutOfMemoryException&) {
                XERCES_STD_QUALIFIER cerr << "OutOfMemoryException" << XERCES_STD_QUALIFIER endl;
                errorCode = 5;
            } catch (const DOMException& e) {
                XERCES_STD_QUALIFIER cerr << "DOMException code is:  " << e.code << XERCES_STD_QUALIFIER endl;
                errorCode = 2;
            } catch (...) {
                XERCES_STD_QUALIFIER cerr << "An error occurred creating the document" << XERCES_STD_QUALIFIER endl;
                errorCode = 3;
            }
        }// (inpl != NULL)
        else {
            XERCES_STD_QUALIFIER cerr << "Requested implementation is not supported" << XERCES_STD_QUALIFIER endl;
            errorCode = 4;
        }
    }

    XMLPlatformUtils::Terminate();
    return errorCode;
}
