var searchData=
[
  ['xmlelestack',['xmlEleStack',['../xml_music_lib_reader_8cpp.html#a9c2bc7cf154c2645e3ca779e08788c3a',1,'xmlMusicLibReader.cpp']]],
  ['xmltemp',['xmlTemp',['../xml_music_lib_reader_8cpp.html#a4f6933f074a2fb6bf0b52b79a86955bd',1,'xmlMusicLibReader.cpp']]]
];
