var searchData=
[
  ['newattr',['newAttr',['../xml_music_lib_reader_8cpp.html#aa7d06bd03600b63e4184895cb263cd5a',1,'xmlMusicLibReader.cpp']]],
  ['newxml',['newXML',['../xml_music_lib_reader_8cpp.html#a047c7922e4f42fe9c51cf96ad795b6ff',1,'xmlMusicLibReader.cpp']]]
];
