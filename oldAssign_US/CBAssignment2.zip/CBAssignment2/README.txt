Hello,
Just wrote this README up to voice one issue ive been having 
with the transferring of my assignment(s).I am not sure if this 
is an issue on your end, and if it isnt please 
ignore this, but personally ive been haveing trouble with
FileZilla and/or PuTTY on my end. Every time I submit and then later
return to my project there seems to be some sort of error
that was not there before I submitted. In one case it stated that
there was a file missing and another gave me errors on every
line in every file of my code. I dont know if this is causing problems
on your end, if it is let me know so that i can submmit the file 
directly from the schools own computers and not from home so it wont 
have to go through FileZilla.

Thank you,
Chris