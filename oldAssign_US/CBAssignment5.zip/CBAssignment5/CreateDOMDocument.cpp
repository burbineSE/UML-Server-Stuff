/* 
 * File:   createDOMDocument.cpp
 * Author: The Apache Software Foundation, http://xerces.apache.org/xerces-c/
 * Editor: Chris Burbine, christopher_burbine@student.uml.edu
 *
 * Created locally on November 6, 2012, 4:45 PM
 * Updated on November 9, 2012, 3:45 PM
 * Updated on November 9, 2012, 7:36 PM
 */

/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * $Id: CreateDOMDocument.cpp 676796 2008-07-15 05:04:13Z dbertoni $
 */

/*
 * This sample illustrates how you can create a DOM tree in memory.
 * It then prints the count of elements in the tree.
 */


// ---------------------------------------------------------------------------
//  Includes
// ---------------------------------------------------------------------------
#include <xercesc/util/PlatformUtils.hpp>
#include <xercesc/util/XMLString.hpp>
#include <xercesc/dom/DOM.hpp>
#include <xercesc/util/OutOfMemoryException.hpp>

#include <xercesc/framework/StdOutFormatTarget.hpp>
#include <xercesc/framework/LocalFileFormatTarget.hpp>
#include <xercesc/parsers/XercesDOMParser.hpp>
#include <xercesc/util/XMLUni.hpp>

#include "DOMTreeErrorReporter.hpp"
#include "DOMPrintFilter.hpp"
#include "DOMPrintErrorHandler.hpp"

#include <string.h>
#include <stdlib.h>

#if defined(XERCES_NEW_IOSTREAMS)
#include <iostream>
#else
#include <iostream.h>
#endif

XERCES_CPP_NAMESPACE_USE

// ---------------------------------------------------------------------------
//  This is a simple class that lets us do easy (though not terribly efficient)
//  trancoding of char* data to XMLCh data.
// ---------------------------------------------------------------------------
class XStr {
public:
    // -----------------------------------------------------------------------
    //  Constructors and Destructor
    // -----------------------------------------------------------------------

    XStr(const char* const toTranscode) {
        // Call the private transcoding method
        fUnicodeForm = XMLString::transcode(toTranscode);
    }

    ~XStr() {
        XMLString::release(&fUnicodeForm);
    }


    // -----------------------------------------------------------------------
    //  Getter methods
    // -----------------------------------------------------------------------

    const XMLCh* unicodeForm() const {
        return fUnicodeForm;
    }

private:
    // -----------------------------------------------------------------------
    //  Private data members
    //
    //  fUnicodeForm
    //      This is the Unicode XMLCh format of the string.
    // -----------------------------------------------------------------------
    XMLCh* fUnicodeForm;
};

#define X(str) XStr(str).unicodeForm()

static char* goutputfile = 0;
static char* gXPathExpression = 0;

// options for DOMLSSerializer's features
static XMLCh* gOutputEncoding = 0;

static bool gSplitCdataSections = true;
static bool gDiscardDefaultContent = true;
static bool gUseFilter = false;
static bool gFormatPrettyPrint = true;
static bool gWriteBOM = false;

/**
 * Prints a parsed xml file in pretty-print format
 * @param doc document to be printed
 * @return return value dependent on the result of the print
 */
int DOMPrint(DOMDocument* doc) {
    int retval = 0;
    
    try{ //attempts to initialize a platform
        XMLPlatformUtils::Initialize();
    }
    
    catch( const XMLException &toCatch){ //catch error os there is an issue
        XERCES_STD_QUALIFIER cerr << "Error during Xerces-c Initialization.\n"
                << "  Exception message:"
                << StrX(toCatch.getMessage()) << XERCES_STD_QUALIFIER endl;
        return 1;
    }
    
    /** possible future error checking value; at the moment does nothing*/
    bool errorsOccured = false;
    
    if (!errorsOccured ) {
        DOMPrintFilter *myFilter = 0;

        try {
            // get a serializer, an instance of DOMLSSerializer
            XMLCh tempStr[3] = {chLatin_L, chLatin_S, chNull};
            DOMImplementation *impl = DOMImplementationRegistry::getDOMImplementation(tempStr);
            DOMLSSerializer *theSerializer = ((DOMImplementationLS*) impl)->createLSSerializer();
            DOMLSOutput *theOutputDesc = ((DOMImplementationLS*) impl)->createLSOutput();

            // set user specified output encoding
            theOutputDesc->setEncoding(gOutputEncoding);

            // plug in user's own filter
            if (gUseFilter) {
                // even we say to show attribute, but the DOMLSSerializer
                // will not show attribute nodes to the filter as
                // the specs explicitly says that DOMLSSerializer shall
                // NOT show attributes to DOMLSSerializerFilter.
                //
                // so DOMNodeFilter::SHOW_ATTRIBUTE has no effect.
                // same DOMNodeFilter::SHOW_DOCUMENT_TYPE, no effect.
                //
                myFilter = new DOMPrintFilter(DOMNodeFilter::SHOW_ELEMENT |
                        DOMNodeFilter::SHOW_ATTRIBUTE |
                        DOMNodeFilter::SHOW_DOCUMENT_TYPE);
                theSerializer->setFilter(myFilter);
            }

            // plug in user's own error handler
            DOMErrorHandler *myErrorHandler = new DOMPrintErrorHandler();
            DOMConfiguration* serializerConfig = theSerializer->getDomConfig();
            serializerConfig->setParameter(XMLUni::fgDOMErrorHandler, myErrorHandler);

            // set feature if the serializer supports the feature/mode
            if (serializerConfig->canSetParameter(XMLUni::fgDOMWRTSplitCdataSections, gSplitCdataSections))
                serializerConfig->setParameter(XMLUni::fgDOMWRTSplitCdataSections, gSplitCdataSections);

            if (serializerConfig->canSetParameter(XMLUni::fgDOMWRTDiscardDefaultContent, gDiscardDefaultContent))
                serializerConfig->setParameter(XMLUni::fgDOMWRTDiscardDefaultContent, gDiscardDefaultContent);

            if (serializerConfig->canSetParameter(XMLUni::fgDOMWRTFormatPrettyPrint, gFormatPrettyPrint))
                serializerConfig->setParameter(XMLUni::fgDOMWRTFormatPrettyPrint, gFormatPrettyPrint);

            if (serializerConfig->canSetParameter(XMLUni::fgDOMWRTBOM, gWriteBOM))
                serializerConfig->setParameter(XMLUni::fgDOMWRTBOM, gWriteBOM);

            //
            // Plug in a format target to receive the resultant
            // XML stream from the serializer.
            //
            // StdOutFormatTarget prints the resultant XML stream
            // to stdout once it receives any thing from the serializer.
            //
            XMLFormatTarget *myFormTarget;
            if (goutputfile)
                myFormTarget = new LocalFileFormatTarget(goutputfile);
            else
                myFormTarget = new StdOutFormatTarget();
            theOutputDesc->setByteStream(myFormTarget);


            //
            // do the serialization through DOMLSSerializer::write();
            //
            if (gXPathExpression != NULL) {
                XMLCh* xpathStr = XMLString::transcode(gXPathExpression);
                DOMElement* root = doc->getDocumentElement();
                try {
                    DOMXPathNSResolver* resolver = doc->createNSResolver(root);
                    DOMXPathResult* result = doc->evaluate(
                            xpathStr,
                            root,
                            resolver,
                            DOMXPathResult::ORDERED_NODE_SNAPSHOT_TYPE,
                            NULL);

                    XMLSize_t nLength = result->getSnapshotLength();
                    for (XMLSize_t i = 0; i < nLength; i++) {
                        result->snapshotItem(i);
                        theSerializer->write(result->getNodeValue(), theOutputDesc);
                    }

                    result->release();
                    resolver->release();
                }                catch (const DOMXPathException& e) {
                    XERCES_STD_QUALIFIER cerr << "An error occurred during processing of the XPath expression. Msg is:"
                            << XERCES_STD_QUALIFIER endl
                            << StrX(e.getMessage()) << XERCES_STD_QUALIFIER endl;
                    retval = 4;
                }                catch (const DOMException& e) {
                    XERCES_STD_QUALIFIER cerr << "An error occurred during processing of the XPath expression. Msg is:"
                            << XERCES_STD_QUALIFIER endl
                            << StrX(e.getMessage()) << XERCES_STD_QUALIFIER endl;
                    retval = 4;
                }
                XMLString::release(&xpathStr);
            } else
                theSerializer->write(doc, theOutputDesc);

            theOutputDesc->release();
            theSerializer->release();

            //
            // Filter, formatTarget and error handler
            // are NOT owned by the serializer.
            //
            delete myFormTarget;
            delete myErrorHandler;

            if (gUseFilter)
                delete myFilter;

        }        catch (const OutOfMemoryException&) {
            XERCES_STD_QUALIFIER cerr << "OutOfMemoryException" << XERCES_STD_QUALIFIER endl;
            retval = 5;
        }        catch (XMLException& e) {
            XERCES_STD_QUALIFIER cerr << "An error occurred during creation of output transcoder. Msg is:"
                    << XERCES_STD_QUALIFIER endl
                    << StrX(e.getMessage()) << XERCES_STD_QUALIFIER endl;
            retval = 4;
        }

    } else
        retval = 4;


    XMLString::release(&gOutputEncoding);

    // And call the termination method
    XMLPlatformUtils::Terminate();

    return retval;
    
}

// ---------------------------------------------------------------------------
//  main
// ---------------------------------------------------------------------------

int main(int argC, char*[]) {
    // Initialize the XML4C2 system.
    try {
        XMLPlatformUtils::Initialize();
    } catch (const XMLException& toCatch) {
        char *pMsg = XMLString::transcode(toCatch.getMessage());
        XERCES_STD_QUALIFIER cerr << "Error during Xerces-c Initialization.\n"
                << "  Exception message:"
                << pMsg;
        XMLString::release(&pMsg);
        return 1;
    }

    // Watch for special case help request
    int errorCode = 0;
    if (argC > 1) {
        XERCES_STD_QUALIFIER cout << "\nUsage:\n"
                "    CreateDOMDocument\n\n"
                "This program creates a new DOM document from scratch in memory.\n"
                "It then prints the count of elements in the tree.\n"
                << XERCES_STD_QUALIFIER endl;
        errorCode = 1;
    }
    if (errorCode) {
        XMLPlatformUtils::Terminate();
        return errorCode;
    }

    {

        DOMImplementation* impl = DOMImplementationRegistry::getDOMImplementation(X("Core"));

        /** code moded here to print course in for including the code name and number, the professor and five students from the roster; 
         data for xml file provided by Prof Heines from http://teaching.cs.uml.edu/~heines/91.204/91.204-2012-13f/204-assn/CreatingADOMDocument-Part1-v01.jsp*/
        if (impl != NULL) {
            try {
                DOMDocument* doc = impl->createDocument(
                        0, // root element namespace URI.
                        X("course"), // root element name
                        0); // document type object (DTD).

                DOMElement* rootElem = doc->getDocumentElement();
                
                DOMComment* topComment = doc->createComment(X("\n"
                        "  File:  /~heines/91.204/91.204-2012-13s/course.xml\n"
                        "  Jesse M. Heines, UMass Lowell Computer Science, heines@cs.uml.edu\n"
                        "  Copyright (c) 2012 by Jesse M. Heines.  All rights reserved.  May be freely\n"
                        "    copied or excerpted for educational purposes with credit to the author.\n"
                        "  updated by JMH on September 21, 2012 at 12:35 PM\n\n"
                        "  N.B. Use &#146; rather than ' in names such as O'Connell to avoid XSL errors.\n"));
                rootElem->appendChild(topComment);
                
                DOMElement* timeStElem = doc->createElement(X("timestamp"));
                rootElem->appendChild(timeStElem);

                DOMText* timeStDataVal = doc->createTextNode(X("updated by JMH on October 27, 2012 at 5:33 PM"));
                timeStElem->appendChild(timeStDataVal);

                DOMElement* titleElem = doc->createElement(X("title"));
                rootElem->appendChild(titleElem);

                DOMText* titleDateVal = doc->createTextNode(X("Computing IV"));
                titleElem->appendChild(titleDateVal);
                
                DOMElement* sectionElem = doc->createElement(X("section"));
                rootElem->appendChild(sectionElem);
                
                DOMText* sectionDataVal = doc->createTextNode(X("201"));
                sectionElem->appendChild(sectionDataVal);
                
                DOMElement* semesterElem = doc->createElement(X("semester"));
                rootElem->appendChild(semesterElem);
                
                DOMText* semesterDataVal = doc->createTextNode(X("2012-13s"));
                semesterElem->appendChild(semesterDataVal);
                
                DOMElement* academic_calendarElem = doc->createElement(X("academic-calendar-link-pdf"));
                rootElem->appendChild(academic_calendarElem);
                
                DOMText* academic_calendarDataVal = doc->createTextNode(X("http://www.uml.edu/docs/Acal_2012F_tcm18-52133.pdf"));
                academic_calendarElem->appendChild(academic_calendarDataVal);
                
                DOMElement* discussion_boardElem = doc->createElement(X("discussion-board"));
                rootElem->appendChild(discussion_boardElem);
                
                DOMText* discussion_boardDataVal = doc->createTextNode(X("http://piazza.com/class#fall2012/91204"));
                discussion_boardElem->appendChild(discussion_boardDataVal);
                
                DOMElement* class_videosElem = doc->createElement(X("class-videos-url"));
                rootElem->appendChild(class_videosElem);
                
                DOMText* class_videosDataVal = doc->createTextNode(X("http://echo360.uml.edu/heines2012/computing4Fall.html"));
                class_videosElem->appendChild(class_videosDataVal);
                
                DOMElement* professorElem = doc->createElement(X("professor"));
                rootElem->appendChild(professorElem);
                
                DOMElement* profNameElem = doc->createElement(X("name"));
                professorElem->appendChild(profNameElem);
                
                DOMText* profNameDataVal = doc->createTextNode(X("Prof. Jesse M. Heines"));
                profNameElem->appendChild(profNameDataVal);
                
                DOMElement* lastnamefirstElem = doc->createElement(X("lastnamefirst"));
                professorElem->appendChild(lastnamefirstElem);
                
                DOMText* lastnamefirstDataVal = doc->createTextNode(X("Heines, Jesse (Computer Science)"));
                lastnamefirstElem->appendChild(lastnamefirstDataVal);
                
                DOMElement* profEmailElem = doc->createElement(X("email"));
                professorElem->appendChild(profEmailElem);
                
                DOMText* profEmailDataVal = doc->createTextNode(X("heines@cs.uml.edu"));
                profEmailElem->appendChild(profEmailDataVal);
                
                DOMElement* rosterElem = doc->createElement(X("roster"));
                rootElem->appendChild(rosterElem);
                
                DOMElement* studentAlvesElem = doc->createElement(X("student"));
                rosterElem->appendChild(studentAlvesElem);
                
                studentAlvesElem->setAttribute(X("name"), X("Alves, Andrew Richard"));
                studentAlvesElem->setAttribute(X("major"), X("Computer Engineering (BSE)"));
                studentAlvesElem->setAttribute(X("wantstobecalled"), X("Andrew"));
                
                DOMElement* studentAlvesEmailElem = doc->createElement(X("email"));
                studentAlvesElem->appendChild(studentAlvesEmailElem);
                
                DOMText* studentAlvesEmailDataVal = doc->createTextNode(X("acdandrew@gmail.com"));
                studentAlvesEmailElem->appendChild(studentAlvesEmailDataVal);
                
                DOMElement* studentColinElem = doc->createElement(X("student"));
                rosterElem->appendChild(studentColinElem);
                
                studentColinElem->setAttribute(X("name"), X("Baillie, Colin Domigan"));
                studentColinElem->setAttribute(X("major"), X("Computer Science (BS)"));
                studentColinElem->setAttribute(X("wantstobecalled"), X("Colin"));
                
                DOMElement* studentColinEmailElem = doc->createElement(X("email"));
                studentColinElem->appendChild(studentColinEmailElem);
                
                DOMText* studentColinEmailDataVal = doc->createTextNode(X("domigan16@gmail.com"));
                studentColinEmailElem->appendChild(studentColinEmailDataVal);
                
                DOMElement* studentDanielElem = doc->createElement(X("student"));
                rosterElem->appendChild(studentDanielElem);
                
                studentDanielElem->setAttribute(X("name"), X("Brook, Daniel M."));
                studentDanielElem->setAttribute(X("major"), X("Computer Science (BS)"));
                studentDanielElem->setAttribute(X("wantstobecalled"), X("Dan"));
                
                DOMElement* studentDanielEmailElem = doc->createElement(X("email"));
                studentDanielElem->appendChild(studentDanielEmailElem);
                
                DOMText* studentDanielEmailDataVal = doc->createTextNode(X("Daniel_Brook@student.uml.edu"));
                studentDanielEmailElem->appendChild(studentDanielEmailDataVal);
                
                DOMElement* studentChrisElem = doc->createElement(X("student"));
                rosterElem->appendChild(studentChrisElem);
                
                studentChrisElem->setAttribute(X("name"), X("Burbine, Christopher"));
                studentChrisElem->setAttribute(X("major"), X("Computer Science (BS)"));
                studentChrisElem->setAttribute(X("wantstobecalled"), X("Chris"));
                
                DOMElement* studentChrisEmailElem = doc->createElement(X("email"));
                studentChrisElem->appendChild(studentChrisEmailElem);
                
                DOMText* studentChrisEmailDataVal = doc->createTextNode(X("Christopher_Burbine@student.uml.edu"));
                studentChrisEmailElem->appendChild(studentChrisEmailDataVal);
                
                DOMElement* studentJoshElem = doc->createElement(X("student"));
                rosterElem->appendChild(studentJoshElem);
                
                studentJoshElem->setAttribute(X("name"), X("Caravetta, Joshua David"));
                studentJoshElem->setAttribute(X("major"), X("Electrical Engineering (BSE)"));
                studentJoshElem->setAttribute(X("wantstobecalled"), X("Josh"));
                
                DOMElement* studentJoshEmailElem = doc->createElement(X("email"));
                studentJoshElem->appendChild(studentJoshEmailElem);
                
                DOMText* studentJoshEmailDataVal = doc->createTextNode(X("Joshua_Caravetta@student.uml.edu"));
                studentJoshEmailElem->appendChild(studentJoshEmailDataVal);
                
                
                //
                // Now count the number of elements in the above DOM tree.
                //

                const XMLSize_t elementCount = doc->getElementsByTagName(X("*"))->getLength();
                XERCES_STD_QUALIFIER cout << "The tree just created contains: " << elementCount
                        << " elements.\n" << XERCES_STD_QUALIFIER endl;
                
                // XML print function call
                DOMPrint( doc );

                doc->release();
            } catch (const OutOfMemoryException&) {
                XERCES_STD_QUALIFIER cerr << "OutOfMemoryException" << XERCES_STD_QUALIFIER endl;
                errorCode = 5;
            } catch (const DOMException& e) {
                XERCES_STD_QUALIFIER cerr << "DOMException code is:  " << e.code << XERCES_STD_QUALIFIER endl;
                errorCode = 2;
            } catch (...) {
                XERCES_STD_QUALIFIER cerr << "An error occurred creating the document" << XERCES_STD_QUALIFIER endl;
                errorCode = 3;
            }
        }// (inpl != NULL)
        else {
            XERCES_STD_QUALIFIER cerr << "Requested implementation is not supported" << XERCES_STD_QUALIFIER endl;
            errorCode = 4;
        }
    }

    XMLPlatformUtils::Terminate();
    return errorCode;
}
