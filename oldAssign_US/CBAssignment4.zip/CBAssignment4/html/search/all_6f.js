var searchData=
[
  ['one_5fline_5fcomment',['ONE_LINE_COMMENT',['../xml_elements_8h.html#acf067a9f09c2b2135f1a80d61e5eb253af4123fd1ebe2fa5c4c5c7d0870cc030f',1,'xmlElements.h']]]
];
