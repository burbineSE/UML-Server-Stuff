var searchData=
[
  ['xmlelements',['xmlElements',['../classxml_elements.html#a8acbcb92aec7058d5e75ae98ebf94508',1,'xmlElements::xmlElements()'],['../classxml_elements.html#a4f83b67fa41be2bbc57f537af786c636',1,'xmlElements::xmlElements(int, string, string, vector&lt; xmlElements * &gt;, vector&lt; Attribute * &gt;, ParserState)']]],
  ['xmlmusiclibreader',['xmlMusicLibReader',['../classxml_music_lib_reader.html#a512200fda85a57d1e295a1d34e2c7a7a',1,'xmlMusicLibReader::xmlMusicLibReader()'],['../classxml_music_lib_reader.html#ab3355745baa3f538489529a7b5c72a34',1,'xmlMusicLibReader::xmlMusicLibReader(const xmlMusicLibReader &amp;orig)']]],
  ['xmltojsonwriter',['xmlToJSONWriter',['../xml_music_lib_reader_8cpp.html#ab4b765c8713bac20841ec96eb3337e41',1,'xmlMusicLibReader.cpp']]],
  ['xmltreedump',['xmlTreeDump',['../xml_music_lib_reader_8cpp.html#a560c15d137438e6101e301b753c7e930',1,'xmlMusicLibReader.cpp']]]
];
