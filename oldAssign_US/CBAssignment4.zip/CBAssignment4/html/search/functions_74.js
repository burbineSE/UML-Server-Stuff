var searchData=
[
  ['trim',['trim',['../xml_music_lib_reader_8cpp.html#af275007b73064f3cfa2120323021862a',1,'xmlMusicLibReader.cpp']]]
];
