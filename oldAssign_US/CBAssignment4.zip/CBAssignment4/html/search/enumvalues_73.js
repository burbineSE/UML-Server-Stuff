var searchData=
[
  ['self_5fclosing_5ftag',['SELF_CLOSING_TAG',['../xml_elements_8h.html#acf067a9f09c2b2135f1a80d61e5eb253a9913dbf171247c30b8695e085ecfb217',1,'xmlElements.h']]],
  ['starting_5fcomment',['STARTING_COMMENT',['../xml_elements_8h.html#acf067a9f09c2b2135f1a80d61e5eb253ac275b6725664d99466fb91888472687e',1,'xmlElements.h']]],
  ['starting_5fdoc',['STARTING_DOC',['../xml_elements_8h.html#acf067a9f09c2b2135f1a80d61e5eb253ad5f8fa8dc51ff48ff0cc427e1fd8a6e6',1,'xmlElements.h']]]
];
