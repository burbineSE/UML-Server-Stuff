var searchData=
[
  ['directive',['DIRECTIVE',['../xml_elements_8h.html#acf067a9f09c2b2135f1a80d61e5eb253ae3852cb010d5e422026faf83b3c16f0e',1,'xmlElements.h']]]
];
