/* 
 * File:   main.c
 * Author: Chris
 *
 * Created on February 6, 2013, 3:48 PM
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */

typedef union {
    float float_32_val_in_32_bits;
    int float_val_int;

    struct sign_exp_mant {
        unsigned mantissa : 23;
        unsigned exponent : 8;
        unsigned sign : 1;
    } f_bits;

    struct single_bits {
        unsigned b0 : 1;
        unsigned b1 : 1;
        unsigned b2 : 1;
        unsigned b3 : 1;
        unsigned b4 : 1;
        unsigned b5 : 1;
        unsigned b6 : 1;
        unsigned b7 : 1;
        unsigned b8 : 1;
        unsigned b9 : 1;
        unsigned b10 : 1;
        unsigned b11 : 1;
        unsigned b12 : 1;
        unsigned b13 : 1;
        unsigned b14 : 1;
        unsigned b15 : 1;
        unsigned b16 : 1;
        unsigned b17 : 1;
        unsigned b18 : 1;
        unsigned b19 : 1;
        unsigned b20 : 1;
        unsigned b21 : 1;
        unsigned b22 : 1;
        unsigned b23 : 1;
        unsigned b24 : 1;
        unsigned b25 : 1;
        unsigned b26 : 1;
        unsigned b27 : 1;
        unsigned b28 : 1;
        unsigned b29 : 1;
        unsigned b30 : 1;
        unsigned b31 : 1;
    } bit;
} float_num;

int main(int argc, char** argv) {

    int i, j, k;
    float_num float_32_num1, float_32_num2, float_32_answer;

    printf("please enter a floating point number and new-line: ");
    scanf("%g", &float_32_num1.float_32_val_in_32_bits);
    printf("please enter a floating point number and new-line: ");
    scanf("%g", &float_32_num2.float_32_val_in_32_bits);

    char bit_string_num1[43];
    char bit_string_num2[43];
    char exp1[9];
    char exp2[9];
    char mant1[28];
    char mant2[28];

    for (i = 0; i < 42; i++) {
        bit_string_num1[i] = ' ';
        bit_string_num2[i] = ' ';
    }
    bit_string_num1[42] = '\0';
    bit_string_num2[42] = '\0';

    /* sign bit */
    bit_string_num1[0] = float_32_num1.bit.b31 ? '1' : '0';

    /*exp bits*/
    bit_string_num1[2] = float_32_num1.bit.b30 ? '1' : '0';
    bit_string_num1[3] = float_32_num1.bit.b29 ? '1' : '0';
    bit_string_num1[4] = float_32_num1.bit.b28 ? '1' : '0';
    bit_string_num1[5] = float_32_num1.bit.b27 ? '1' : '0';

    bit_string_num1[7] = float_32_num1.bit.b26 ? '1' : '0';
    bit_string_num1[8] = float_32_num1.bit.b25 ? '1' : '0';
    bit_string_num1[9] = float_32_num1.bit.b24 ? '1' : '0';
    bit_string_num1[10] = float_32_num1.bit.b23 ? '1' : '0';

    /*mant bits*/
    bit_string_num1[12] = float_32_num1.bit.b22 ? '1' : '0';
    bit_string_num1[13] = float_32_num1.bit.b21 ? '1' : '0';
    bit_string_num1[14] = float_32_num1.bit.b20 ? '1' : '0';

    bit_string_num1[16] = float_32_num1.bit.b19 ? '1' : '0';
    bit_string_num1[17] = float_32_num1.bit.b18 ? '1' : '0';
    bit_string_num1[18] = float_32_num1.bit.b17 ? '1' : '0';
    bit_string_num1[19] = float_32_num1.bit.b16 ? '1' : '0';

    bit_string_num1[21] = float_32_num1.bit.b15 ? '1' : '0';
    bit_string_num1[22] = float_32_num1.bit.b14 ? '1' : '0';
    bit_string_num1[23] = float_32_num1.bit.b13 ? '1' : '0';
    bit_string_num1[24] = float_32_num1.bit.b12 ? '1' : '0';

    bit_string_num1[26] = float_32_num1.bit.b11 ? '1' : '0';
    bit_string_num1[27] = float_32_num1.bit.b10 ? '1' : '0';
    bit_string_num1[28] = float_32_num1.bit.b9 ? '1' : '0';
    bit_string_num1[29] = float_32_num1.bit.b8 ? '1' : '0';

    bit_string_num1[31] = float_32_num1.bit.b7 ? '1' : '0';
    bit_string_num1[32] = float_32_num1.bit.b6 ? '1' : '0';
    bit_string_num1[33] = float_32_num1.bit.b5 ? '1' : '0';
    bit_string_num1[34] = float_32_num1.bit.b4 ? '1' : '0';

    bit_string_num1[36] = float_32_num1.bit.b3 ? '1' : '0';
    bit_string_num1[37] = float_32_num1.bit.b2 ? '1' : '0';
    bit_string_num1[38] = float_32_num1.bit.b1 ? '1' : '0';
    bit_string_num1[39] = float_32_num1.bit.b0 ? '1' : '0';

    /* sign bit */
    bit_string_num2[0] = float_32_num2.bit.b31 ? '1' : '0';

    /*exp bits*/
    bit_string_num2[2] = float_32_num2.bit.b30 ? '1' : '0';
    bit_string_num2[3] = float_32_num2.bit.b29 ? '1' : '0';
    bit_string_num2[4] = float_32_num2.bit.b28 ? '1' : '0';
    bit_string_num2[5] = float_32_num2.bit.b27 ? '1' : '0';

    bit_string_num2[7] = float_32_num2.bit.b26 ? '1' : '0';
    bit_string_num2[8] = float_32_num2.bit.b25 ? '1' : '0';
    bit_string_num2[9] = float_32_num2.bit.b24 ? '1' : '0';
    bit_string_num2[10] = float_32_num2.bit.b23 ? '1' : '0';

    /*mant bits*/
    bit_string_num2[12] = float_32_num2.bit.b22 ? '1' : '0';
    bit_string_num2[13] = float_32_num2.bit.b21 ? '1' : '0';
    bit_string_num2[14] = float_32_num2.bit.b20 ? '1' : '0';

    bit_string_num2[16] = float_32_num2.bit.b19 ? '1' : '0';
    bit_string_num2[17] = float_32_num2.bit.b18 ? '1' : '0';
    bit_string_num2[18] = float_32_num2.bit.b17 ? '1' : '0';
    bit_string_num2[19] = float_32_num2.bit.b16 ? '1' : '0';

    bit_string_num2[21] = float_32_num2.bit.b15 ? '1' : '0';
    bit_string_num2[22] = float_32_num2.bit.b14 ? '1' : '0';
    bit_string_num2[23] = float_32_num2.bit.b13 ? '1' : '0';
    bit_string_num2[24] = float_32_num2.bit.b12 ? '1' : '0';

    bit_string_num2[26] = float_32_num2.bit.b11 ? '1' : '0';
    bit_string_num2[27] = float_32_num2.bit.b10 ? '1' : '0';
    bit_string_num2[28] = float_32_num2.bit.b9 ? '1' : '0';
    bit_string_num2[29] = float_32_num2.bit.b8 ? '1' : '0';

    bit_string_num2[31] = float_32_num2.bit.b7 ? '1' : '0';
    bit_string_num2[32] = float_32_num2.bit.b6 ? '1' : '0';
    bit_string_num2[33] = float_32_num2.bit.b5 ? '1' : '0';
    bit_string_num2[34] = float_32_num2.bit.b4 ? '1' : '0';

    bit_string_num2[36] = float_32_num2.bit.b3 ? '1' : '0';
    bit_string_num2[37] = float_32_num2.bit.b2 ? '1' : '0';
    bit_string_num2[38] = float_32_num2.bit.b1 ? '1' : '0';
    bit_string_num2[39] = float_32_num2.bit.b0 ? '1' : '0';

    int bit_string_place = 12;

    //printf("num1: %s\n", bit_string_num1);
    //printf("num2: %s\n", bit_string_num2);

    for (j = 0; j < 28; j++) {
        mant1[j] = bit_string_num1[ bit_string_place ];
        mant2[j] = bit_string_num2[ bit_string_place ];
        bit_string_place++;
    }

    bit_string_place = 2;

    for (k = 0; k < 9; k++) {
        exp1[k] = bit_string_num1[ bit_string_place ];
        exp2[k] = bit_string_num2[ bit_string_place ];
        bit_string_place++;
    }

    /*
    printf("mant1: ");
    for (k = 0; k < 28; k++) {
        printf("%c", mant1[k]);
    }
    printf("\n");
    printf("mant2: ");
    for (k = 0; k < 28; k++) {
        printf("%c", mant2[k]);
    }
    printf("\n");
    printf("exp1: ");
    for (k = 0; k < 9; k++) {
        printf("%c", exp1[k]);
    }
    printf("\n");
    printf("exp2: ");
    for (k = 0; k < 9; k++) {
        printf("%c", exp2[k]);
    }*/

    char mant1_HB[29];
    char mant2_HB[29];
    mant1_HB[0] = '1';
    mant2_HB[0] = '1';

    for (k = 1; k < 29; k++) {
        mant1_HB[k] = mant1[k - 1];
        mant2_HB[k] = mant2[k - 1];
    }

    printf("\n");
    printf("mant1_HB: ");
    for (k = 0; k < 29; k++) {
        printf("%c", mant1_HB[k]);
    }
    printf("\n");
    printf("mant2_HB: ");
    for (k = 0; k < 29; k++) {
        printf("%c", mant2_HB[k]);
    }

    int weight_counter, exp1_expVal, exp2_expVal;
    int exp_finalVal = 0;

    /*
    printf("exp1: ");
    for (k = 0; k < 9; k++) {
        printf("%c", exp1[k]);
    }
    printf("\n");
    printf("exp2: ");
    for (k = 0; k < 9; k++) {
        printf("%c", exp2[k]);
    }
    printf("\n");*/

    if (exp1[0] == '1') {
        exp1_expVal = 0;
        weight_counter = 1;
        for (i = 8; i > 0; i--) {
            if (exp1[i] == '1') {
                exp1_expVal = exp1_expVal + weight_counter;
                //printf("exp1_expVal: %d", exp1_expVal);
                //printf("\n");
            }
            if (exp1[i] != ' ') {
                weight_counter = weight_counter * 2;
                //printf("weight: %d", weight_counter);
                //printf("\n");
            }
        }
        exp1_expVal++;
        //printf("final expVal1: %d", exp1_expVal);
        //printf("\n");
    }

    //printf("\n");

    if (exp2[0] == '1') {
        exp2_expVal = 0;
        weight_counter = 1;
        for (i = 8; i > 0; i--) {
            if (exp2[i] == '1') {
                exp2_expVal = exp2_expVal + weight_counter;
                //printf("exp2_expVal: %d", exp2_expVal);
                //printf("\n");
            }
            if (exp2[i] != ' ') {
                weight_counter = weight_counter * 2;
                //printf("weight: %d", weight_counter);
                //printf("\n");
            }
        }
        exp2_expVal++;
        //printf("final expVal2: %d", exp2_expVal);
        //printf("\n");
    }

    if (exp1[0] == '0') {
        exp1_expVal = 0;
        weight_counter = 1;
        for (i = 8; i > 0; i--) {
            if (exp1[i] == '0') {
                exp1_expVal = exp1_expVal - weight_counter;
                //printf("exp1_expVal: %d", exp1_expVal);
                //printf("\n");
            }
            if (exp1[i] != ' ') {
                weight_counter = weight_counter * 2;
                //printf("weight: %d", weight_counter);
                //printf("\n");
            }
        }
        //printf("final expVal1: %d", exp1_expVal);
        //printf("\n");
    }

    //printf("\n");

    if (exp2[0] == '0') {
        exp2_expVal = 0;
        weight_counter = 1;
        for (i = 8; i > 0; i--) {
            if (exp2[i] == '0') {
                exp2_expVal = exp2_expVal - weight_counter;
                //printf("exp2_expVal: %d", exp2_expVal);
                //printf("\n");
            }
            if (exp2[i] != ' ') {
                weight_counter = weight_counter * 2;
                //printf("weight: %d", weight_counter);
                //printf("\n");
            }
        }
        //printf("final expVal2: %d", exp2_expVal);
        //printf("\n");
    }

    int num1_bigger = 0;
    int num2_bigger = 0;

    if (exp1_expVal > exp2_expVal && exp2_expVal > 0) {
        exp_finalVal = exp1_expVal - exp2_expVal;
        num1_bigger = 1;
    }
    if (exp1_expVal > exp2_expVal && exp2_expVal < 0) {
        exp_finalVal = exp1_expVal + exp2_expVal;
        num1_bigger = 1;
    }

    if (exp2_expVal > exp1_expVal && exp1_expVal > 0) {
        exp_finalVal = exp2_expVal - exp1_expVal;
        num2_bigger = 1;
    }
    if (exp2_expVal > exp1_expVal && exp1_expVal < 0) {
        exp_finalVal = exp2_expVal + exp1_expVal;
        num2_bigger = 1;
    }

    if (exp1_expVal == 0) {
        exp_finalVal = exp2_expVal;
        num2_bigger = 1;
    }
    if (exp2_expVal == 0) {
        exp_finalVal = exp1_expVal;
        num1_bigger = 1;
    }

    printf("\nexp fin: %d\n", exp_finalVal);

    //if( num1_bigger == 1) printf("\nnum1 is bigger\n");
    //if( num2_bigger == 1) printf("\nnum2 is bigger\n");

    char mant_small_temp[24];
    char mant_small[29];
    char mant_fin[29];
    int zero_counter = exp_finalVal;

    for (i = 0; i < 29; i++) {
        mant_small[i] = ' ';
    }
    for (i = 0; i < 24; i++) {
        mant_small_temp[i] = ' ';
    }

    i = 0;
    while (zero_counter > 4) {
        zero_counter = zero_counter - 4;
        i++;
    }
    //printf("%d\n", i);
    int small_mant_start = 29 - (exp_finalVal + i);
    printf("%d", small_mant_start);

    if (num1_bigger == 1) {
        char num1, num2;
        int carry = 0;
        int counter1 = 28;
        int counter2 = 28 - small_mant_start;

        for (i = 28; i > 0; i--) {
            num1 = mant1_HB[i];
            num2 = mant2_HB[i - small_mant_start];
            while ((i - small_mant_start) > 0) {
                if (num1 == ' ' && num2 == ' ') {
                    mant_fin[i] = ' ';
                }
                if (num1 != ' ' && num2 == ' ') {
                    num2 = mant2_HB[i - small_mant_start + 1];
                    i++;
                }
                if (num1 == ' ' && num2 != ' ') {
                    num2 = mant2_HB[i - small_mant_start - 1];
                    i--;
                }
                if (num1 != ' ' && num2 != ' ') {
                    if (num1 == '0' && num2 == '0') {
                        if (carry == 1) {
                            mant_fin[i] = '1';
                            carry = 0;
                        } else {
                            mant_fin[i] = '0';
                        }
                    }
                    if (num1 == '1' && num2 == '0') {
                        if (carry == 1) {
                            mant_fin[i] = '0';
                        } else {
                            mant_fin[i] = '1';
                        }
                    }
                    if (num1 == '0' && num2 == '1') {
                        if (carry == 1) {
                            mant_fin[i] = '0';
                        } else {
                            mant_fin[i] = '1';
                        }
                    }
                    if (num1 == '1' && num2 == '1') {
                        if (carry == 1) {
                            mant_fin[i] = '1';
                        } else {
                            mant_fin[i] = '0';
                            carry = 1;
                        }
                    }

                }
            }
        }
    }
    

    return (EXIT_SUCCESS);
}

