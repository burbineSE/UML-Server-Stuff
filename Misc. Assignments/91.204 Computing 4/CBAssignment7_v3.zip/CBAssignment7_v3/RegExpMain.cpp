/**
 *  File:  /~heines/91.204/91.204-2012-13f/204-lecs/code/BoostRegexTests/RegExTests.cpp
 *  Jesse M. Heines, UMass Lowell Computer Science, heines@cs.uml.edu
 *  Copyright (c) 2012 by Jesse M. Heines.  All rights reserved.  May be freely
 *    copied or excerpted for educational purposes with credit to the author.
 *  updated by JMH on November 19, 2012 at 8:12 PM
 *  updated by JMH on November 23, 2012 at 9:58 PM
 */

#include <iostream>  // for cout and friends
#include <sstream>   // for string streams
#include <string>    // for the STL string class

#include <boost/regex.hpp>              // for regex_match
#include <boost/algorithm/string.hpp>   // for iequals (case-insensitive match)
// the Boost string library contains many string manipulation functions not found in
//    the STL library that you may be familiar with from Java or JavaScript, such as
//    case-insensitive comparisons and trimming
// see http://stackoverflow.com/questions/11635/case-insensitive-string-comparison-in-c
// see http://www.boost.org/doc/libs/1_52_0/doc/html/string_algo/usage.html
// see http://www.boost.org/doc/libs/1_52_0/doc/html/string_algo/reference.html


using namespace std; // to eliminate the need for std::
using namespace boost; // to eliminate the need for boost::

#include <xercesc/util/PlatformUtils.hpp>
#include <xercesc/util/XMLString.hpp>
#include <xercesc/dom/DOM.hpp>
#include <xercesc/util/OutOfMemoryException.hpp>

#include <xercesc/framework/StdOutFormatTarget.hpp>
#include <xercesc/framework/LocalFileFormatTarget.hpp>
#include <xercesc/parsers/XercesDOMParser.hpp>
#include <xercesc/util/XMLUni.hpp>

#include "DOMTreeErrorReporter.hpp"
#include "DOMPrintFilter.hpp"
#include "DOMPrintErrorHandler.hpp"

/**
 * Trims leading and tailing white space and tab from string passed
 * Function written by Prof. Heines, taken from class notes Sept. 18, 2012
 * @param str xml file line in
 * @return trimmed line to be used in the parse
 */
string trim(string& str) {
    //cout << "Trimming |" << str << "|" << endl;
    while (str[0] == ' ' || str[0] == '\t') {
        str.erase(str.begin());
        //cout << "Front trimmed |" << str << "|" << endl;
    }
    while (str [ str.length() - 1] == ' ' || str [ str.length() - 1] == '\t') {
        str.erase(str.end() - 1);
        //cout << "Back Trimmed |" << str << "|" << endl;
    }
    //cout << "Trimmed |" << str << "|" << endl;
    return str;
}

// ---------------------------------------------------------------------------
//  This is a simple class that lets us do easy (though not terribly efficient)
//  trancoding of char* data to XMLCh data.
// ---------------------------------------------------------------------------

class XStr {
public:
    // -----------------------------------------------------------------------
    //  Constructors and Destructor
    // -----------------------------------------------------------------------

    XStr(const char* const toTranscode) {
        // Call the private transcoding method
        fUnicodeForm = XMLString::transcode(toTranscode);
    }

    ~XStr() {
        XMLString::release(&fUnicodeForm);
    }


    // -----------------------------------------------------------------------
    //  Getter methods
    // -----------------------------------------------------------------------

    const XMLCh* unicodeForm() const {
        return fUnicodeForm;
    }

private:
    // -----------------------------------------------------------------------
    //  Private data members
    //
    //  fUnicodeForm
    //      This is the Unicode XMLCh format of the string.
    // -----------------------------------------------------------------------
    XMLCh* fUnicodeForm;
};

#define X(str) XStr(str).unicodeForm()

static char* goutputfile = 0;
static char* gXPathExpression = 0;

// options for DOMLSSerializer's features
static XMLCh* gOutputEncoding = 0;

static bool gSplitCdataSections = true;
static bool gDiscardDefaultContent = true;
static bool gUseFilter = false;
static bool gFormatPrettyPrint = true;
static bool gWriteBOM = false;

int DOMPrint(DOMDocument* doc) {
    int retval = 0;

    try { //attempts to initialize a platform
        XMLPlatformUtils::Initialize();
    } catch (const XMLException &toCatch) { //catch error os there is an issue
        XERCES_STD_QUALIFIER cerr << "Error during Xerces-c Initialization.\n"
                << "  Exception message:"
                << StrX(toCatch.getMessage()) << XERCES_STD_QUALIFIER endl;
        return 1;
    }

    /** possible future error checking value; at the moment does nothing*/
    bool errorsOccured = false;

    if (!errorsOccured) {
        DOMPrintFilter *myFilter = 0;

        try {
            // get a serializer, an instance of DOMLSSerializer
            XMLCh tempStr[3] = {chLatin_L, chLatin_S, chNull};
            DOMImplementation *impl = DOMImplementationRegistry::getDOMImplementation(tempStr);
            DOMLSSerializer *theSerializer = ((DOMImplementationLS*) impl)->createLSSerializer();
            DOMLSOutput *theOutputDesc = ((DOMImplementationLS*) impl)->createLSOutput();

            // set user specified output encoding
            theOutputDesc->setEncoding(gOutputEncoding);

            // plug in user's own filter
            if (gUseFilter) {
                // even we say to show attribute, but the DOMLSSerializer
                // will not show attribute nodes to the filter as
                // the specs explicitly says that DOMLSSerializer shall
                // NOT show attributes to DOMLSSerializerFilter.
                //
                // so DOMNodeFilter::SHOW_ATTRIBUTE has no effect.
                // same DOMNodeFilter::SHOW_DOCUMENT_TYPE, no effect.
                //
                myFilter = new DOMPrintFilter(DOMNodeFilter::SHOW_ELEMENT |
                        DOMNodeFilter::SHOW_ATTRIBUTE |
                        DOMNodeFilter::SHOW_DOCUMENT_TYPE);
                theSerializer->setFilter(myFilter);
            }

            // plug in user's own error handler
            DOMErrorHandler *myErrorHandler = new DOMPrintErrorHandler();
            DOMConfiguration* serializerConfig = theSerializer->getDomConfig();
            serializerConfig->setParameter(XMLUni::fgDOMErrorHandler, myErrorHandler);

            // set feature if the serializer supports the feature/mode
            if (serializerConfig->canSetParameter(XMLUni::fgDOMWRTSplitCdataSections, gSplitCdataSections))
                serializerConfig->setParameter(XMLUni::fgDOMWRTSplitCdataSections, gSplitCdataSections);

            if (serializerConfig->canSetParameter(XMLUni::fgDOMWRTDiscardDefaultContent, gDiscardDefaultContent))
                serializerConfig->setParameter(XMLUni::fgDOMWRTDiscardDefaultContent, gDiscardDefaultContent);

            if (serializerConfig->canSetParameter(XMLUni::fgDOMWRTFormatPrettyPrint, gFormatPrettyPrint))
                serializerConfig->setParameter(XMLUni::fgDOMWRTFormatPrettyPrint, gFormatPrettyPrint);

            if (serializerConfig->canSetParameter(XMLUni::fgDOMWRTBOM, gWriteBOM))
                serializerConfig->setParameter(XMLUni::fgDOMWRTBOM, gWriteBOM);

            //
            // Plug in a format target to receive the resultant
            // XML stream from the serializer.
            //
            // StdOutFormatTarget prints the resultant XML stream
            // to stdout once it receives any thing from the serializer.
            //
            XMLFormatTarget *myFormTarget;
            if (goutputfile)
                myFormTarget = new LocalFileFormatTarget(goutputfile);
            else
                myFormTarget = new StdOutFormatTarget();
            theOutputDesc->setByteStream(myFormTarget);


            //
            // do the serialization through DOMLSSerializer::write();
            //
            if (gXPathExpression != NULL) {
                XMLCh* xpathStr = XMLString::transcode(gXPathExpression);
                DOMElement* root = doc->getDocumentElement();
                try {
                    DOMXPathNSResolver* resolver = doc->createNSResolver(root);
                    DOMXPathResult* result = doc->evaluate(
                            xpathStr,
                            root,
                            resolver,
                            DOMXPathResult::ORDERED_NODE_SNAPSHOT_TYPE,
                            NULL);

                    XMLSize_t nLength = result->getSnapshotLength();
                    for (XMLSize_t i = 0; i < nLength; i++) {
                        result->snapshotItem(i);
                        theSerializer->write(result->getNodeValue(), theOutputDesc);
                    }

                    result->release();
                    resolver->release();
                } catch (const DOMXPathException& e) {
                    XERCES_STD_QUALIFIER cerr << "An error occurred during processing of the XPath expression. Msg is:"
                            << XERCES_STD_QUALIFIER endl
                            << StrX(e.getMessage()) << XERCES_STD_QUALIFIER endl;
                    retval = 4;
                } catch (const DOMException& e) {
                    XERCES_STD_QUALIFIER cerr << "An error occurred during processing of the XPath expression. Msg is:"
                            << XERCES_STD_QUALIFIER endl
                            << StrX(e.getMessage()) << XERCES_STD_QUALIFIER endl;
                    retval = 4;
                }
                XMLString::release(&xpathStr);
            } else
                theSerializer->write(doc, theOutputDesc);

            theOutputDesc->release();
            theSerializer->release();

            //
            // Filter, formatTarget and error handler
            // are NOT owned by the serializer.
            //
            delete myFormTarget;
            delete myErrorHandler;

            if (gUseFilter)
                delete myFilter;

        } catch (const OutOfMemoryException&) {
            XERCES_STD_QUALIFIER cerr << "OutOfMemoryException" << XERCES_STD_QUALIFIER endl;
            retval = 5;
        } catch (XMLException& e) {
            XERCES_STD_QUALIFIER cerr << "An error occurred during creation of output transcoder. Msg is:"
                    << XERCES_STD_QUALIFIER endl
                    << StrX(e.getMessage()) << XERCES_STD_QUALIFIER endl;
            retval = 4;
        }

    } else
        retval = 4;


    XMLString::release(&gOutputEncoding);

    // And call the termination method
    XMLPlatformUtils::Terminate();

    return retval;

}

/**
 * Function called to add elements to the tree
 * @param name name of new node
 * @param cont content of new node, maybe empty
 * @param parentNode name of node where the new node will be appended under
 * @param doc document in which all this is occurring
 * @param rootElem shows the walker where to start
 */
void addELem(std::string name, std::string cont, std::string parentNode, DOMDocument* doc, DOMElement *rootElem) {

    //creates a walker to move along the tree
    DOMTreeWalker* walker = doc->createTreeWalker(rootElem, DOMNodeFilter::SHOW_ALL, NULL, true);
    //for loop iterates through the tree
    for (DOMNode* current = walker->getCurrentNode(); current != 0; current = walker->nextNode()) {
        //std::cout << "Entering loop" << std::endl;
        const char* temp = XMLString::transcode(current->getNodeName());
        //attaches new node to tree when the correct parent node is found
        if (temp == parentNode) {
            //std::cout << "Creating new node" << std::endl;
            DOMElement *newElement = doc->createElement(X(name.c_str()));
            //std::cout << "Attaching new node" << std::endl;
            current->appendChild(newElement);

            //attaches content to new node if there is any
            int size = cont.size();
            if (size > 0) {
                DOMText* newElementCont = doc->createTextNode(X(cont.c_str()));
                newElement->appendChild(newElementCont);
            }

            //DOMPrint( doc );
        }
    }
}

/**
 * Function called to add attributes to a tree
 * @param name name of new attribute
 * @param val value of new attribute
 * @param parentNode name of node the attribute will be placed under
 * @param doc document which this is happening in
 * @param rootElem shows walker where to start
 */
void addAttr(std::string name, std::string val, std::string parentNode, DOMDocument* doc, DOMElement* rootElem) {
    //creates a walker to move along the tree
    DOMTreeWalker* walker = doc->createTreeWalker(rootElem, DOMNodeFilter::SHOW_ALL, NULL, true);
    //for loop iterates through the tree
    for (DOMNode* current = walker->getCurrentNode(); current != 0; current = walker->nextNode()) {
        const char* temp = XMLString::transcode(current->getNodeName());
        //attaches new node to tree when the correct parent node is found
        if (temp == parentNode) {
            DOMAttr *newAttr = doc->createAttribute(X(name.c_str()));

            int size = val.size();
            if (size > 0) {
                newAttr->setValue(X(val.c_str()));
            }
            DOMNamedNodeMap *newMap = current->getAttributes();
            newMap->setNamedItem(newAttr);

            //DOMPrint( doc );
        }
    }
}
// main function; based off of the function test2_BasicCommandParsing_c1() from Prof. Heines' starter code
int main(int argC, char*[]) {

    string strCmd[10];
    string strCmdUser;

    strCmd[0] = " add element root first one";
    strCmd[1] = "  add element root second";
    strCmd[2] = "  add  attribute  first   attr1 attr1value";
    strCmd[3] = "  add  attribute  second  attr2";
    strCmd[4] = "print";
    strCmd[5] = "add element second elem cont";
    strCmd[6] = "quit";
    strCmd[7] = "another command";
    int nCmds = 8;

    bool loopingBool = true;

    cmatch what;
    // what[0] contains the entire matched string
    // what[1] contains the first matched group
    // what[2] contains the second matched group
    // what[3] etc.

    //regular expressions taken from Prof. Heines' starter program(RegexTests.cpp)
    regex reBasicCmd("^\\s*(add|print|quit).*", boost::regex::icase);
    regex reAddCmd("^\\s*add\\s+(element|attribute)\\s(.+)\\s(.+)\\s*(.*)\\s*$", boost::regex::icase);
    //regex reAddElementCmd("^\\s*add\\s*element\\s(.+)\\s(.+)\\s*(.*)$", boost::regex::icase);
    //regex reAddAttributeCmd("^\\s*add\\s*attribute\\s(.+)\\s(.+)\\s*(.*)$", boost::regex::icase);
    //regex reQuitCmd("^\\s*quit", boost::regex::icase);
    //regex reWhat("^\\s*[a-zA-Z]{1,}\\s*[a-zA-Z]{1,}\\s*(.*)$", boost::regex::icase);
    //regex reAddOnlyCmd("^\\s*a(d|dd).*", boost::regex::icase);
    //regex rePrintOnlyCmd("^\\s*p(r|ri|rin|rint).*", boost::regex::icase);
    //regex reQuitOnlyCmd("^\\s*q(u|ui|uit).*", boost::regex::icase);
    //regex reElemOnlyCmd(".*\\s*e(l|le|lem|leme|lemen|lement).*", boost::regex::icase);
    //regex reAttrOnlyCmd(".*\\s*a(t|tt|ttr|ttri|ttrib|ttribu|ttribut|ttribute).*", boost::regex::icase);

    string newNodeName;
    string newNodeContVal;
    string newNodeParent;

    try {
        XMLPlatformUtils::Initialize();
    } catch (const XMLException& toCatch) {
        char *pMsg = XMLString::transcode(toCatch.getMessage());
        XERCES_STD_QUALIFIER cerr << "Error during Xerces-c Initialization.\n"
                << "  Exception message:"
                << pMsg;
        XMLString::release(&pMsg);
        return 1;
    }
    int errorCode = 0;
    if (errorCode) {
        XMLPlatformUtils::Terminate();
        return errorCode;
    }

    {
        DOMImplementation* impl = DOMImplementationRegistry::getDOMImplementation(X("Core"));

        if (impl != NULL) {
            try {
                DOMDocument* doc = impl->createDocument(
                        0, // root element namespace URI.
                        X("root"), // root element name
                        0); // document type object (DTD).

                DOMElement* rootElem = doc->getDocumentElement();

                cout << "Base root node created." << endl;
                //cout << "Current XML file:" << endl;
                //DOMPrint( doc );

                // loop through all hard-coded command strings for testing purposes
                while (loopingBool == true) {
                //for (int n = 0; n < nCmds; n++) {

                    // user entry point
                    cout << "\nYour command: ";
                    char chrCmdUser[ 256 ] ;
                    cin.getline( chrCmdUser, 256 ) ;
                    strCmdUser = chrCmdUser ;
                    // cout << strCmd[n] << endl;
                    cout << strCmdUser << endl ;

                    // string version of a matched group
                    // for building a bridge between the cmatch type and an STL sting so that we can
                    //    process matches with STL string functions
                    string strWhat;

                    // test for a match of a basic command
                    if (regex_match(strCmdUser.c_str(), what, reBasicCmd)){
                    //if (regex_match(strCmd[n].c_str(), what, reBasicCmd)) {
                        cout << "  what.size() = " << what.size() << endl;
                        for (int k = 0; k < what.size(); k++) {
                            strWhat = what[k];
                            cout << "    what[" << k << "] = " << what[k] << " (" << strWhat.size() << " chars)" << endl;
                        }
                        // handle an ADD command
                        //if( strWhat == "a", strWhat == "ad", strWhat == "add"){
                        //if (regex_match(strCmd[n].c_str(), what, reAddOnlyCmd)){
                        if ( iequals( strWhat, "add" ) ) {
                            cout << "  Command is ADD" << endl;
                            cout << strCmdUser << endl ;
                            cout << reAddCmd << endl ;
                            cout << regex_match( strCmdUser.c_str(), what, reAddCmd ) << endl ;

                            // test for a match on the second word in the command
                            if ( regex_match(strCmdUser.c_str(), what, reAddCmd)){
                            // if (regex_match(strCmd[n].c_str(), what, reAddCmd)) {
                                for (int k = 0; k < what.size(); k++) {
                                    strWhat = what[k];
                                    cout << "    what[" << k << "] = " << what[k] << " (" << strWhat.size() << " chars)" << endl;
                                }
                                strWhat = what[1];
                                //cout << "What[1]: " << strWhat << endl;
                                // handle an ADD ELEMENT command
                                //if (regex_match(strCmd[n].c_str(), what, reElemOnlyCmd)){
                                if (iequals(strWhat, "element")) {
                                    cout << "Command is ADD ELEMENT" << endl;
                                    
                                    //function deals with what[2]; had issues with getting the command line split as i wanted it to, used this instead
                                    
                                    strWhat = what[2];
                                    cout << "What[2]: " << strWhat << endl;
                                    if (strWhat.size() > 0) {
                                        strWhat = trim(strWhat);
                                        //cout << "Str: " << strWhat << endl;
                                        int space = strWhat.find_first_of(" ");
                                        if (space > 0) {
                                            newNodeParent = strWhat.substr(0, space);
                                            cout << "Parent: " << newNodeParent << endl;
                                            int end = strWhat.size();
                                            newNodeName = strWhat.substr(space, (end - 1));
                                            newNodeName = trim(newNodeName);
                                            cout << "New node(elem) name: " << newNodeName << endl;

                                            strWhat = what[3];
                                            newNodeContVal = strWhat;
                                            cout << "New node content: " << newNodeContVal << endl;
                                        } else {
                                            newNodeParent = strWhat;
                                            cout << "Parent: " << newNodeParent << endl;

                                            strWhat = what[3];
                                            newNodeName = strWhat;
                                            cout << "New node(elem) name: " << newNodeName << endl;

                                            newNodeContVal = "";
                                        }
                                    }
                                    addELem(newNodeName, newNodeContVal, newNodeParent, doc, rootElem);
                                    DOMPrint( doc );
                                }// handle an ADD ATTRIBUTE command
                                else if (iequals(strWhat, "attribute")) {
                                    cout << "  Command is ADD ATTRIBUTE" << endl;

                                    //function deals with what[2]; had issues with getting the command line split as i wanted it to, used this instead
                                    strWhat = what[2];
                                    //newNodeContVal = "";
                                    if (strWhat.size() > 0) {
                                        strWhat = trim(strWhat);
                                        //cout << "Str: " << strWhat << endl;
                                        int space = strWhat.find_first_of(" ");
                                        if (space > 0) {
                                            newNodeParent = strWhat.substr(0, space);
                                            //cout << "Parent: " << newNodeParent << endl;
                                            int end = strWhat.size();
                                            newNodeName = strWhat.substr(space, (end - 1));
                                            newNodeName = trim(newNodeName);
                                            //cout << "New node(attr) name: " << newNodeName << endl;

                                            strWhat = what[3];
                                            newNodeContVal = strWhat;
                                            //cout << "New node value: " << newNodeContVal << endl;
                                        } else {
                                            newNodeParent = strWhat;
                                            //cout << "Parent: " << newNodeParent << endl;

                                            strWhat = what[3];
                                            newNodeName = strWhat;
                                            //cout << "New node(attr) name: " << newNodeName << endl;

                                            newNodeContVal = "";
                                        }
                                    }
                                    addAttr(newNodeName, newNodeContVal, newNodeParent, doc, rootElem);
                                    //DOMPrint( doc );
                                }// parsing error: ADD is followed by an invalid keyword
                                else {
                                    cout << "Invalid ADD command: 2nd word must be 'element' or 'attribute'." << endl;
                                }
                            }// parsing error: ADD command syntax does not match the regular expression
                            else {
                                cout << "Invalid ADD command syntax." << endl;
                            }
                        }// handle a PRINT command
                        else if (iequals(strWhat, "print")) {
                            DOMPrint( doc );
                        }// handle a QUIT command
                        else if (iequals(strWhat, "quit")) {
                            cout << "Goodbye." << endl;
                            loopingBool = false;
                            return 0;
                        }// parsing error: the first keyword is not ADD, PRINT, or QUIT
                        else {
                            cout << "  Invalid command: 1st word must be 'add', 'print', or 'quit'." << endl;
                        }
                    }
                }
                doc->release();
            }catch (const OutOfMemoryException&) {
                XERCES_STD_QUALIFIER cerr << "OutOfMemoryException" << XERCES_STD_QUALIFIER endl;
                errorCode = 5;
            }catch (const DOMException& e) {
                XERCES_STD_QUALIFIER cerr << "DOMException code is:  " << e.code << XERCES_STD_QUALIFIER endl;
                errorCode = 2;
            }catch (...) {
                XERCES_STD_QUALIFIER cerr << "An error occurred creating the document" << XERCES_STD_QUALIFIER endl;
                errorCode = 3;
            }
        }
    }
}
