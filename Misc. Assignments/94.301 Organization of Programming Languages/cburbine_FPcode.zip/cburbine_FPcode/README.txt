	I am submitting three files: julia.rkt (which creatsa Julia set), mandel.rkt 
(which creates a Mandelbrot set) and newton.rkt (which creates a Newton set). Each file 
renders a unique fractal upon running; each render may take some time to appear (~1-2 
minutes). The files have a similar structure breaking down into four main parts:

�	The RGB Vectors: at the top of each file there is a list of 12 vectors each with
 	a length of 32. Values are drawn from these vectors that represent the RGB color
	 of a given pixel

�	The Color Calculator Function: This function is called by the OpenGL drawing 
	function to find the correct RGB for some x-y coordinate. 

�	The OpenGL Drawing Function: the function that prepares the drawing buffers and 
	renders the image. 

�	The GUI Window Function: This function builds and prepares the window the fractal
	 image will be placed in. 

	I preformed the most amount of work on the RGB vectors. Most of what I found 
about color tables in OpenGL was either based on built in functionality or 2-D arrays. 
Not having either of these in scheme forced me to build my own system for producing an 
RGB. 
	My code exhibits mainly recursion in the color calculation function, which loops
 until it hits a value greater than the current radius. Then, based on the current 
iteration, it calls the appropriate three vectors to get the required RGB.
	To run the code in Racket simply hit either F5 or Ctrl-R, this should bring up a
 window and after a bit the fractal should appear.  
